# cascadia

[![](https://travis-ci.org/andybalholm/cascadia.svg)](https://travis-ci.org/andybalholm/cascadia)

The Cascadia package implements CSS selectors for use with the parse trees produced by the html package.
