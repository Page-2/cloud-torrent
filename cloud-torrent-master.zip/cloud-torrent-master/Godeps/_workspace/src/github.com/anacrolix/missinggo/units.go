package missinggo

const MiB = 1 << 20
