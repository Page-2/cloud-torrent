package missinggo

// I would implement StopAndDrainTimer here, but time.Timer is broken in the standard library.
